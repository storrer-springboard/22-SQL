# SQL Zoo
Answers to all tutorials from SQLZoo; content from: http://sqlzoo.net/wiki/SQL_Tutorial. 
